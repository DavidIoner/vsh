#Hey !
Thanks for downloading and using my library !!!

This library allows you to read the raw data from a MPU6050 multifunctional accelerometer,
compute them and then allows you to do whatever you want with them!

Why did I call this library "GY6050" and not MPU6050 ?
Well because the name was already taken... And if you want
to experiment with the one called "MPU6050", it won't interfere
with this one, and vice-versa.

open the readme.txt for more info and a tutorial on how to use this library !!!

Thanks for reading this,
Frédéric Druppel.

#P.S.:
When you have unzipped the .zip file, remove "-master" from the name of the folder before installing the library.
Otherwise, the library could not work properly.
