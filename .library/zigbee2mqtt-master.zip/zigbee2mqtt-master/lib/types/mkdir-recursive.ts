declare module 'mkdir-recursive' {
    export function mkdirSync(path: string): void;
}
